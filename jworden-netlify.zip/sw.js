const CACHE_NAME = 'jworden-v1';
const STATIC_ASSETS = [
  '/',
  '/styles.css',
  '/manifest.json',
  '/images/commercial-parking-lot.jpg',
  '/images/asphalt-paving-project.jpg',
  '/images/residential-driveway.jpg',
  '/images/parking-lot.jpg',
  '/images/sealcoating.jpg',
  '/images/asphalt-repair.jpg',
  '/images/line-striping.jpg',
  '/images/grading-excavation.jpg',
  '/images/driveway-install.jpg',
  '/images/new-asphalt-driveway.jpg',
  '/images/commercial-asphalt.jpg',
  '/images/asphalt-excavation.jpg',
  '/images/parking-lot-roller.jpg',
  '/images/chip-tar-surface.jpg',
  '/images/sealcoating-driveway.jpg',
  '/images/kfc-parking-lot-milling.jpg'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(STATIC_ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200 || response.type !== 'basic') return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => caches.match('/'));
    })
  );
});
